1.本模板基于电子科大硕士王稳学长的模板（https://github.com/wanygen/ThesisUESTC.git）修改，参考了时富军学长的模板（https://github.com/shifujun/UESTCthesis.git）
2.如果发现插入pdf图片，没有显示，没有报错，那么请检查pdf图片的版本和latex生成pdf的版本，如果插入pdf版本高则无法显示
3.本模板基于教务处2016年10月要求更改
4.建议使用王稳学长的或者这个（本模板在Ubuntu下面一切正常，王的有小bug），xelatex可直接使用Times New Roman字体用于数学公式，避免纠结字体

